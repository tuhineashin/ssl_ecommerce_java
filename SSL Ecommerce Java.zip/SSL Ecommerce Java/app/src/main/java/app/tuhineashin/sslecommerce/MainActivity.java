package app.tuhineashin.sslecommerce;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCCustomerInfoInitializer;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCProductInitializer;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCShipmentInfoInitializer;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfoModel;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCCurrencyType;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCSdkType;
import com.sslwireless.sslcommerzlibrary.view.singleton.IntegrateSSLCommerz;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCTransactionResponseListener;

public class MainActivity extends AppCompatActivity implements SSLCTransactionResponseListener{
    TextInputEditText amount_ed;
    Button pay_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        amount_ed  = findViewById(R.id.amount_ed);
        pay_btn  = findViewById(R.id.pay_btn);

      /*    This Source Code was developed by Tuhin Eashin
         Tuhin Eashin is a Professional Android App Developer
         Contact him (eashinmd997@gmail.com)

         */

        pay_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String amount = amount_ed.getText().toString();


                if (amount_ed.length()>0){
                    int value = Integer.parseInt(amount);
                    final SSLCommerzInitialization sslCommerzInitialization = new SSLCommerzInitialization ("nexde63e48d9521823","nexde63e48d9521823@ssl", value, SSLCCurrencyType.BDT,"123456789098765", "yourProductType", SSLCSdkType.TESTBOX);

                    final SSLCCustomerInfoInitializer customerInfoInitializer = new SSLCCustomerInfoInitializer("customer name", "customer email",
                            "address", "dhaka", "1214", "Bangladesh", "phoneNumber");


                    final SSLCProductInitializer productInitializer = new SSLCProductInitializer ("food", "food",
                            new SSLCProductInitializer.ProductProfile.TravelVertical("Travel", "10",
                                    "A", "12", "Dhk-Syl"));

                    final SSLCShipmentInfoInitializer shipmentInfoInitializer = new SSLCShipmentInfoInitializer ("Courier",
                            2, new SSLCShipmentInfoInitializer.ShipmentDetails("AA","Address 1",
                            "Dhaka","1000","BD"));


                    IntegrateSSLCommerz
                            .getInstance(MainActivity.this)
                            .addSSLCommerzInitialization(sslCommerzInitialization)
                            .addCustomerInfoInitializer(customerInfoInitializer)
                            .addProductInitializer(productInitializer)
                            .buildApiCall((SSLCTransactionResponseListener) MainActivity.this);


                } else {
                    amount_ed.setError("input Some Value");
                }


            }
        });






    } //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    @Override
    public void transactionSuccess(SSLCTransactionInfoModel sslcTransactionInfoModel) {
        // success.setText(""+sslcTransactionInfoModel.getAPIConnect()+"---"+sslcTransactionInfoModel.getStatus());
        Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void transactionFail(String s) {
        // failed.setText(""+s);
        Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closed(String s) {
        // cancel.setText(""+s);
        Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show();
    }
}